import javax.swing.JFrame;


public class ChronoInterface extends JFrame{
	
}
